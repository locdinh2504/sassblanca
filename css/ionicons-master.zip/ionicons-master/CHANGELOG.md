# [5.0.0-11](https://github.com/ionic-team/ionicons/compare/v5.0.0-0...v5.0.0-11) (2019-10-18)

### Refactor

* **refactor:** update v5 icons ([1be0c8e](https://github.com/ionic-team/ionicons/commit/1be0c8eb219c76b18baba25596251cdec78ac9b4))
* **color:** fix fill and stroke currentColor ([f0d22cc](https://github.com/ionic-team/ionicons/commit/f0d22cc))
* **svg:** add source svgs to distribution ([279de85](https://github.com/ionic-team/ionicons/commit/279de85))
* **svg:** add source svgs to distribution ([279de85](https://github.com/ionic-team/ionicons/commit/279de8512ce91b1c20cc68c016dce31d779959b0))
* **toggle:** rename switch to toggle ([dfb62b6](https://github.com/ionic-team/ionicons/commit/dfb62b67e05ce396b4fb7b0e149c6ce19010b13a))
* **types:** update package.json types ([993a314](https://github.com/ionic-team/ionicons/commit/993a314eb6383cba906b997f7631c9c14523c670))
